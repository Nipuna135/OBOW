import { T as jsxRuntimeExports } from "./worker-entry-CWHMerU4.js";
import { g as groupph, a as bhantesImg } from "./router-DHWao1k0.js";
import "node:events";
import "node:async_hooks";
import "node:stream/web";
import "node:stream";
function AboutPage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative h-[60vh] min-h-[420px] flex items-center justify-center overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: groupph, alt: "Sunlight through temple pillars", width: 1600, height: 1024, className: "absolute inset-0 w-full h-full object-cover" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-b from-maroon-deep/40 to-background" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 text-center px-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "lotus-divider text-xs uppercase tracking-[0.4em] text-accent mb-6", children: "Our Story" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-serif text-5xl md:text-7xl text-primary-foreground drop-shadow", children: "About Us" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-24 px-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl mx-auto space-y-16", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.3em] text-accent mb-4", children: "Mission" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-4xl text-primary mb-6", children: "A Single Path, A Single World" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg text-foreground/80 leading-relaxed font-light", children: "One Buddha One World exists to share the timeless teachings of the Buddha with every corner of humanity. We are a global sangha — monastic and lay, young and old, from every culture and language — united in the conviction that the Dharma belongs to all." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.3em] text-accent mb-4", children: "Vision" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-4xl text-primary mb-6", children: "A World Awakened to Compassion" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg text-foreground/80 leading-relaxed font-light", children: "We envision a world where wisdom replaces fear, where compassion guides our shared decisions, and where every being — human and otherwise — is recognised as worthy of kindness. The Dharma is the bridge." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid md:grid-cols-2 gap-10 items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative rounded-2xl overflow-hidden shadow-md h-80 md:h-[480px]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: bhantesImg, alt: "Ven. Anurudda Thero and Ven. Miao Tsan at the Inauguration Ceremony, Sigiriya, Sri Lanka", className: "w-full h-full object-cover" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "absolute bottom-2 right-3 text-[10px] text-white/60 tracking-wide", children: "Photo © CNews" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.3em] text-accent mb-4", children: "From the Venerable Masters" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-serif text-4xl text-primary mb-6", children: "Religion Knows No Borders" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg text-foreground/80 leading-relaxed font-light", children: `The "One Buddha One World" Buddhist international organization was jointly initiated by Taiwan's Ven. Shih Da Hui of Guang Xiu Zen Monastery, Sri Lanka's Ven. Anurudda Thero, and Ven. Miao Tsan of Vairochana Zen Monastery in the United States — and was grandly established in the Buddhist nation of Sri Lanka on 31st May 2025.` }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-lg text-foreground/80 leading-relaxed font-light", children: "United across borders, traditions, and languages, these three Venerable Masters share a single conviction: that the Dharma belongs to every being on this earth, without exception." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-[3fr_2fr] gap-10 items-center", children: [{
        num: "23+",
        label: "Countries reached"
      }, {
        num: "10,000+",
        label: "Sangha members"
      }, {
        num: "2+",
        label: "Annual events"
      }].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center p-8 rounded-2xl bg-gradient-warm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-serif text-5xl text-gradient-gold", children: s.num }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 text-sm text-muted-foreground uppercase tracking-widest", children: s.label })
      ] }, s.label)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center pt-8 border-t border-border/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-serif italic text-2xl text-primary", children: '"Thousands of candles can be lit from a single candle, and the life of the candle will not be shortened."' }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm uppercase tracking-widest text-accent", children: "— The Buddha" })
      ] })
    ] }) })
  ] });
}
export {
  AboutPage as component
};
